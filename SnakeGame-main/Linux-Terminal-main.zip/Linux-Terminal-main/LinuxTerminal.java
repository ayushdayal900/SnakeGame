package FDS_PROJECT;    
// import javax.swing.*;


public class LinuxTerminal {
    public static void main(String[] args) {
        terminal t = new terminal();
        t.command();  // init commands in an array list
        
    }
}

