# Linux-Terminal
Creating a linux terminal on the basis of Java Programming.
